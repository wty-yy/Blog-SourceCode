## 入门CMake
代码包含5个项目：
1. main：不包含任何依赖项，可直接编译
2. sfml：需要安装sfml包
3. matplotlib：参考[Blog  - matplotlib](https://wty-yy.github.io/posts/50507/#matplotlib)
4. tensorboard：参考[Blog - tensorboard](https://wty-yy.github.io/posts/50507/#tensorboard)
5. libtorch：参考[Blog - libtorch](https://wty-yy.github.io/posts/50507/#libtorch)

如果只想编译部分文件，在`CMakeLists.txt`中注释掉不需要的项目即可。

CMake编译方法：

1. 终端：
```bash
# 进入到根目录下
mkdir my_build  # 创建文件夹
cmake -B my_build  # 创建cmake缓存
# 可选--target编译目标, 如果没有指定则是全部编译
# 注意: --target后面是最后编译出的目标（可执行文件）名称
cmake --build my_build --target [main|sfml|matplotlib|tensorboard|torch_tensor]
# 以运行torch_tensor为例
./my_build/libtorch/torch_tensor
```

2. VSCode：安装插件`CMake Tools`在左侧CMake图标中配置即可。