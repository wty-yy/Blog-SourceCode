#include <iostream>
#include "bar.h"

int main() {
  std::cout << "Hello world\n";
  Bar().foo();
  Bar().show();
  double a = 1, b = 2;
  std::cout << a << ' ' << b << '\n';
  return 0;
}