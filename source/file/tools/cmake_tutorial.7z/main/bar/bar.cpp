#include "bar.h"

void Bar::show() {
  std::cout << "print in bar.cpp\n";
}