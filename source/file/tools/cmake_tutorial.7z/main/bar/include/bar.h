#pragma once
#include <iostream>

class Bar {
  public:
    inline void foo() {
      std::cout << "Foo!\n";
    }
    void show();
};