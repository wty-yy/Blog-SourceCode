#include <torch/torch.h>

using namespace torch;

int main() {
  double avg_time = 0;
  for (int i = 0; i < 100; i++) {
    Tensor a = torch::rand({1024, 4096});
    Tensor b = torch::rand({4096, 1024});
    auto t1 = std::chrono::high_resolution_clock::now();
    Tensor c = a.mm(b);
    auto t2 = std::chrono::high_resolution_clock::now();
    auto duration_milli = std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1);
    avg_time += ((double)duration_milli.count() - avg_time) / (i + 1);
    std::cout << c[0][0].item() << '\n';
  }
  std::cout << avg_time << "ms\n";
}