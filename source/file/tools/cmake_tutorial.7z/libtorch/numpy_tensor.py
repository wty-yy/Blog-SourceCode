import numpy as np
from time import time

avg_time = 0
for i in range(100):
  start_time = time()
  a = np.random.rand(1024, 4096)
  b = np.random.rand(4096, 1024)
  c = a @ b
  duration = time() - start_time
  avg_time += (duration - avg_time) / (i + 1)
  print(c[0,0])
print(f"avg time used: {avg_time*1000:.2f}ms")

