#include <tensorboard_logger.h>
#include <cmath>

int main() {
  TensorBoardLogger logger("./demo/tfevents_scale.pb");
  const int N = 100;
  for (int i = 0; i < N; i++) {
    double x = 2.0 * M_PI * i / N;
    logger.add_scalar("test/sin", i, std::sin(x));
    logger.add_scalar("test/cos", i, std::cos(x));
  }
  google::protobuf::ShutdownProtobufLibrary();
  std::cout << "draw scaler, finished!\n";
  return 0;
}
