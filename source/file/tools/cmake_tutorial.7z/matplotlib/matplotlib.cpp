#include <cmath>
#include "matplotlibcpp.h"
#define kwargs std::map<std::string, std::string>

using namespace std;
namespace plt = matplotlibcpp;

int main1()
{
    // Prepare data.
    int n = 5000; // number of data points
    vector<double> x(n),y(n);
    for(int i=0; i<n; ++i) {
        double t = 2*M_PI*i/n;
        x.at(i) = 16*sin(t)*sin(t)*sin(t);
        y.at(i) = 13*cos(t) - 5*cos(2*t) - 2*cos(3*t) - cos(4*t);
    }

    // plot() takes an arbitrary number of (x,y,format)-triples.
    // x must be iterable (that is, anything providing begin(x) and end(x)),
    // y must either be callable (providing operator() const) or iterable.
    plt::plot(x, y, "r-", x, [](double d) { return 12.5+abs(sin(d)); }, "k-");


    // show plots
    plt::show();
    return 0;
}

int main2() {
  plt::fontsize(18);

  int n = 5000;
  std::vector<double> x(n), y(n), z(n), w(n, 2);
  for (int i = 0; i < n; i++) {
    x[i] = i * i;
    y[i] = sin(2 * M_PI * i / 360);
    z[i] = log(i);
  }
  plt::figure_size(1200, 780);
  plt::plot(x, y);
  plt::plot(x, w, kwargs({{"c", "r"}, {"ls", "--"}, {"label", "$\\sin(2\\pi/360)$"}}));
  plt::named_plot("$\\log(x)$", x, z);
  std::map<std::string, std::string> m = {{"string", "123"}, {"a", "aa"}};
  std::cout << m["string"] << ' ' << m["a"] << '\n';
  plt::xlim(0.0, 1e6);
  plt::legend(kwargs({{"loc", "upper left"}}));
  plt::title("标题");
  plt::show();
  return 0;
}

int main() {
  std::cout << "HI" << '\n';
  plt::fontsize(18);
  plt::figure_size(600, 500);
  int n = 5e3;
  vector<double> x(n), y(n);
  for (int i = 0; i < n; ++i) {
    double t = 2 * M_PI * i / n;
    x[i] = 16 * pow(sin(t), 3);
    y[i] = 13 * cos(t) - 5 * cos(2 * t) - 2 * cos(3 * t) - cos(4 * t);
  }
  auto y_func = [](double d) {return 3.5 + abs(sin(d));};
  plt::text(-8, 5, "Tom");
  plt::text(5, 5, "Jerry");
  plt::fontsize(12);
  plt::plot(vector<double>(x.begin()+1200, x.end()-1200), y_func, "k-");
  plt::plot(x, y, "r-");
  plt::text(-11.0, -2.0, "$x=16\\sin(t)^3,$\n$y=13\\cos(t)-5\\cos(2t)-2\\cos(3t)-\\cos(4t))$");
  // plt::plot(x, y, "r-", x, [](double d) { return 12.5+abs(sin(d)); }, "k-");
  // plt::legend();
  plt::save("love.png", 300);
  plt::tight_layout();
  plt::show();
}
