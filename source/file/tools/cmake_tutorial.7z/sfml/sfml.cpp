#include <SFML/Graphics.hpp>

int main() {
    // 创建一个窗口
    sf::RenderWindow window(sf::VideoMode(800, 600), "SFML Simple Demo");

    // 创建一个矩形形状
    sf::RectangleShape rectangle(sf::Vector2f(100, 50)); // 宽100，高50
    rectangle.setFillColor(sf::Color::Green); // 设置填充颜色为绿色
    rectangle.setPosition(350, 275); // 设置初始位置在窗口中心

    // 矩形移动速度
    float speed = 0.1f;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close(); // 关闭窗口事件
        }

        // 移动矩形
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
            if (rectangle.getPosition().x > 0) { // 检查左边界
                rectangle.move(-speed, 0); // 向左移动
            }
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
            if (rectangle.getPosition().x + rectangle.getSize().x < window.getSize().x) { // 检查右边界
                rectangle.move(speed, 0); // 向右移动
            }
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
            if (rectangle.getPosition().y > 0) { // 检查上边界
                rectangle.move(0, -speed); // 向上移动
            }
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
            if (rectangle.getPosition().y + rectangle.getSize().y < window.getSize().y) { // 检查下边界
                rectangle.move(0, speed); // 向下移动
            }
        }

        // 清空窗口
        window.clear(sf::Color::Black); // 清空为黑色
        // 绘制矩形
        window.draw(rectangle);
        // 显示窗口内容
        window.display();
    }

    return 0;
}
